import { useState } from 'react';
import AIModelCard from '../components/AIModelCard';
import { AIModel } from '../types';

export default function Home() {
  const [models] = useState<AIModel[]>([
    {
      id: 1,
      name: 'Text Generation',
      description: 'Generate human-like text for various purposes',
      icon: '📝',
    },
    {
      id: 2,
      name: 'Image Recognition',
      description: 'Analyze and understand images with AI',
      icon: '🖼️',
    },
    {
      id: 3,
      name: 'Voice Assistant',
      description: 'Natural language processing and voice commands',
      icon: '🎤',
    },
  ]);

  return (
    <div>
      <section className="text-center mb-16">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Welcome to AI Platform
        </h1>
        <p className="text-xl text-gray-600">
          Explore our cutting-edge AI models and solutions
        </p>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {models.map((model) => (
          <AIModelCard key={model.id} model={model} />
        ))}
      </section>
    </div>
  );
}