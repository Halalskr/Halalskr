import { useState } from 'react';
import StatsCard from '../../components/admin/StatsCard';

export default function Dashboard() {
  const [stats] = useState([
    { name: 'Total Users', value: '1,234', change: '+12%' },
    { name: 'Active Models', value: '15', change: '+3' },
    { name: 'API Requests', value: '45.8k', change: '+23%' },
  ]);

  return (
    <div>
      <h1 className="text-2xl font-semibold text-gray-900 mb-8">Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat) => (
          <StatsCard key={stat.name} {...stat} />
        ))}
      </div>
    </div>
  );
}