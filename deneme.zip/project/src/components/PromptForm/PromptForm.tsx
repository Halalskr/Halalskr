import React from 'react';
import { PromptInput } from './PromptInput';
import { SubmitButton } from './SubmitButton';
import { ImageGenerationRequest } from '../../types/image';

interface PromptFormProps {
  onSubmit: (data: ImageGenerationRequest) => Promise<void>;
  isLoading: boolean;
}

export function PromptForm({ onSubmit, isLoading }: PromptFormProps) {
  const [prompt, setPrompt] = React.useState('');
  const [negativePrompt, setNegativePrompt] = React.useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;
    await onSubmit({ prompt, negativePrompt });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <PromptInput
        value={prompt}
        onChange={setPrompt}
        label="Prompt"
        placeholder="Enter your image description..."
      />
      <PromptInput
        value={negativePrompt}
        onChange={setNegativePrompt}
        label="Negative Prompt (Optional)"
        placeholder="Enter things to avoid in the image..."
      />
      <SubmitButton isLoading={isLoading} />
    </form>
  );
}