import { AIModel } from '../types';

interface AIModelCardProps {
  model: AIModel;
}

export default function AIModelCard({ model }: AIModelCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      <div className="text-4xl mb-4">{model.icon}</div>
      <h3 className="text-xl font-semibold mb-2">{model.name}</h3>
      <p className="text-gray-600">{model.description}</p>
    </div>
  );
}