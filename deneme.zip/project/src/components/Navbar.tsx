import { Link } from 'react-router-dom';

export default function Navbar() {
  return (
    <nav className="bg-white shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="text-xl font-bold text-gray-800">
              AI Platform
            </Link>
          </div>
          <div className="flex items-center">
            <Link
              to="/admin"
              className="px-4 py-2 rounded-md text-gray-600 hover:text-gray-900"
            >
              Admin
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}