import { PromptForm } from './PromptForm/PromptForm';
import { GeneratedImage } from './GeneratedImage/GeneratedImage';
import { useImageGeneration } from '../hooks/useImageGeneration';
import { ImageGenerationRequest } from '../types/image';

export function ImageGenerator() {
  const { generate, isLoading, currentImage } = useImageGeneration();

  const handleSubmit = async (data: ImageGenerationRequest) => {
    await generate(data);
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <PromptForm onSubmit={handleSubmit} isLoading={isLoading} />
      {currentImage && <GeneratedImage image={currentImage} />}
    </div>
  );
}