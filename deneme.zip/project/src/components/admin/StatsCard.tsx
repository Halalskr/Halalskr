import React from 'react';
import { Stats } from '../../types';

export default function StatsCard({ name, value, change }: Stats) {
  const isPositive = change.startsWith('+');
  
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h3 className="text-sm font-medium text-gray-500">{name}</h3>
      <div className="mt-2 flex items-baseline justify-between">
        <div className="text-2xl font-semibold text-gray-900">{value}</div>
        <div className={`text-sm ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
          {change}
        </div>
      </div>
    </div>
  );
}