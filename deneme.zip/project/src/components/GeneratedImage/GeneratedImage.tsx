import { GeneratedImage as GeneratedImageType } from '../../types/image';

interface GeneratedImageProps {
  image: GeneratedImageType;
}

export function GeneratedImage({ image }: GeneratedImageProps) {
  return (
    <div className="mt-8">
      <h2 className="text-lg font-medium text-gray-900 mb-4">Generated Image</h2>
      <img
        src={image.url}
        alt={image.prompt}
        className="w-full rounded-lg shadow-lg"
      />
      <p className="mt-2 text-sm text-gray-500">
        Prompt: {image.prompt}
      </p>
    </div>
  );
}