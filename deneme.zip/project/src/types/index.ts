export interface AIModel {
  id: number;
  name: string;
  description: string;
  icon: string;
}

export interface User {
  id: number;
  name: string;
  email: string;
  role: 'user' | 'admin';
  status: 'active' | 'inactive';
}

export interface Stats {
  name: string;
  value: string;
  change: string;
}