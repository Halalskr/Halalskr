import axios from 'axios';
import { ImageGenerationRequest } from '../types/image';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000/api';

export async function generateImage({ prompt, negativePrompt }: ImageGenerationRequest): Promise<string> {
  try {
    const response = await axios.post(`${API_URL}/generate`, {
      prompt,
      negativePrompt
    });
    return response.data.image;
  } catch (error) {
    console.error('Error generating image:', error);
    throw error;
  }
}