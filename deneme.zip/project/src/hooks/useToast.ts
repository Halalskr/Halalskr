import toast from 'react-hot-toast';

export function useToast() {
  const showError = (message: string) => toast.error(message);
  const showSuccess = (message: string) => toast.success(message);

  return {
    showError,
    showSuccess
  };
}