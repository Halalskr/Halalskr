import { useState } from 'react';
import { generateImage } from '../services/imageApi';
import { ImageGenerationRequest, GeneratedImage } from '../types/image';
import { useToast } from '../hooks/useToast';

export function useImageGeneration() {
  const [isLoading, setIsLoading] = useState(false);
  const [currentImage, setCurrentImage] = useState<GeneratedImage | null>(null);
  const { showError } = useToast();

  const generate = async ({ prompt, negativePrompt }: ImageGenerationRequest) => {
    setIsLoading(true);
    try {
      const base64Image = await generateImage({ prompt, negativePrompt });
      const newImage: GeneratedImage = {
        url: `data:image/png;base64,${base64Image}`,
        prompt,
        timestamp: Date.now()
      };
      setCurrentImage(newImage);
      return newImage;
    } catch (error) {
      showError('Failed to generate image');
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    generate,
    isLoading,
    currentImage
  };
}